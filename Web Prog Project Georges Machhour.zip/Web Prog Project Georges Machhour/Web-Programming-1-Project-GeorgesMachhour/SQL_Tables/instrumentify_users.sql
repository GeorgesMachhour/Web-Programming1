CREATE DATABASE  IF NOT EXISTS `instrumentify` ;
USE `instrumentify`;

 SET NAMES utf8 ;


DROP TABLE IF EXISTS `users`;

 SET character_set_client = utf8 ;
CREATE TABLE `users` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `Password` varchar(25) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

LOCK TABLES `users` WRITE;

INSERT INTO `users` VALUES (1,'admin','admin@admin.com','admin123');

UNLOCK TABLES;

